const webview = document.querySelector('.webview');
const homepage = document.querySelector('.homepage');

const goBackButton = document.querySelector('.go-back-button');
const goForwardButton = document.querySelector('.go-forward-button');
const reloadButton = document.querySelector('.reload-button');
const homeButton = document.querySelector('.home-button');

const urlForm = document.querySelector('.url-form');
const urlInput = document.querySelector('.url-input');

const searchBarForm = document.querySelector('.search-bar-form');
const searchBarInput = document.querySelector('.search-bar-input');

const githubLink = document.querySelector('.github-link');

const openDevToolsButton = document.querySelector('.open-dev-tools-button');

let isOnHomePage;

setHomePage(true);

setURLInputValue();
function setURLInputValue() {
    setTimeout(function () {
        // Check if urlForm has focus right now
        if (isOnHomePage) {
            if (urlInput !== document.activeElement) {
                urlInput.value = '';
            }
        }
        else {
            if (urlInput !== document.activeElement) {
                urlInput.value = webview.getAttribute('src');
            }
        }

        setURLInputValue();
    }, 100);
}

function validURL(str) {
    var pattern = new RegExp('^(https?:\\/\\/)?' +
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' +
        '((\\d{1,3}\\.){3}\\d{1,3}))' +
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' +
        '(\\?[;&a-z\\d%_.~+=-]*)?' +
        '(\\#[-a-z\\d_]*)?$', 'i');
    return !!pattern.test(str);
}

// Go back
goBackButton.addEventListener('click', () => {
    webview.goBack();
})

// Go forward
goForwardButton.addEventListener('click', () => {
    webview.goForward();
})

// Reload
reloadButton.addEventListener('click', () => {
    webview.reload();
})

// Home 
homeButton.addEventListener('click', () => {
    setHomePage(true);
})

// URL input
urlForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // If it's a valid URL we go to that page, else search google for query
    if (validURL(urlInput.value)) {
        webview.setAttribute('src', urlInput.value);
    }
    else {
        webview.setAttribute('src', `https://www.google.com/search?q=${urlInput.value}`);
    }
})

// Search bar
searchBarForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // If it's a valid URL we go to that page, else search google for query
    if (validURL(searchBarInput.value)) {
        webview.setAttribute('src', searchBarInput.value);
    }
    else {
        webview.setAttribute('src', `https://www.google.com/search?q=${searchBarInput.value}`);
    }
})

// Github link
githubLink.addEventListener('click', () => {
    webview.setAttribute('src', 'https://github.com/lordmaltazor');
})

// Unloading the homepage once the new page has finished loading
webview.addEventListener('did-finish-load', () => {
    setHomePage(false);
})

// Activating and de-activating the homepage
function setHomePage(isActive) {
    isOnHomePage = isActive;

    webview.style.display = isActive ? 'none' : 'flex';
    homepage.style.display = isActive ? 'flex' : 'none';

    searchBarInput.value = '';
}

// Open dev-tools button
openDevToolsButton.addEventListener('click', () => {
    webview.openDevTools();
})